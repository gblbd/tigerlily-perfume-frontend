//   //for pages
//   const togglePagesDropdown = () => setPagesDropdownOpen(!pagesDropdownOpen);
//   const pagesDropdownClose = () => setPagesDropdownOpen(false);

//   //for clinics
//   const toggleMenuDropdown = () => setMenuDropdownOpen(!menuDropdownOpen);
//   const menuDropdownClose = () => setMenuDropdownOpen(false);

//   //for blog
//   const toggleBlogDropdown = () => setBlogDropdownOpen(!blogDropdownOpen);
//   const blogDropdownClose = () => setBlogDropdownOpen(false);

//   //for search button icon
//   const handleSearchOpen = () => {
//     setIsSearchOpen(!isSearchOpen);
//   };
//   const handleSearchClosed = () => setIsSearchOpen(false);

//   //toggle function

//   const toggleMenu = () => {
//     setIsMenuOpen((prevIsMenuOpen) => !prevIsMenuOpen);
//   };

//   //services menu
//   const toggleServicesDropdown = () =>
//     setServicesDropdownOpen(!servicesDropdownOpen);
//   const servicesDropdownClose = () => setServicesDropdownOpen(false);

//   //shop menu
//   const toggleShopDropdown = () => setShopDropdownOpen(!shopDropdownOpen);
//   const shopDropdownClose = () => setShopDropdownOpen(false);

//   //sub menu for blog
//   const toggleBloggridDropdown = () =>
//     setBloggridDropdownOpen(!bloggridDropdownOpen);
//   const bloggridDropdownClose = () => setBloggridDropdownOpen(false);
